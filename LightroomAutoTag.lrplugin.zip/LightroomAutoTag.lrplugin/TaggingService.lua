local LrTasks = import 'LrTasks'
local LrPathUtils = import 'LrPathUtils'
local LrFileUtils = import 'LrFileUtils'
local LrDialogs = import 'LrDialogs'
local json      = require 'json'

local TaggingService = {}

function TaggingService.getTagsForImages(jsonFile)
    -- The python script expects: clip_multilabel.py /path/to/photo_paths.json [top_k] [threshold]
    local scriptPath = LrPathUtils.child(
        LrPathUtils.parent(LrPathUtils.scriptPath),
        "clip_multilabel.py"
    )

    local command = string.format(
        'python3 "%s" "%s" %d %.2f',
        scriptPath,
        jsonFile,
        10,    -- top_k
        0.21   -- threshold
    )

    local result = nil
    -- We run the command in a blocking manner so we can parse the output
    LrTasks.execute(command, function(stdout, stderr)
        if stderr and #stderr > 0 then
            LrDialogs.message("Python Error", stderr, "critical")
        end
        result = stdout
    end)

    if not result or #result == 0 then
        return {}
    end

    -- The Python script will output JSON, e.g.
    -- [
    --   {"image_path": "/path/to/image1.jpg", "tags": [["Landscape", 0.85], ["Sunset", 0.77]]},
    --   {"image_path": "/path/to/image2.jpg", "tags": [["Portrait", 0.93]]},
    --   ...
    -- ]
    local success, data = pcall(json.decode, result)
    if success and data and type(data) == "table" then
        return data
    else
        return {}
    end
end

return TaggingService
